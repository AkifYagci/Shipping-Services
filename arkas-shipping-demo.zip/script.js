const { sqrt, pow, sin, cos, PI } = Math;
let { innerHeight: height, innerWidth: width } = window;

// Animation state
const animation = {
  progress: 0,
  isAnimating: false
};

// Map settings
const mapSettings = {
  projection: 'orthographic',
  colorTheme: 'ocean',
  zoom: 500,
  routeType: 'direct',
  animationSpeed: 1.0,
  showLabels: true
};

// Color themes
const colorThemes = {
  ocean: {
    water: '#1e3a8a',
    waterStroke: '#1e40af',
    land: '#f3f4f6',
    landStroke: '#d1d5db'
  },
  satellite: {
    water: '#0f172a',
    waterStroke: '#1e293b',
    land: '#22c55e',
    landStroke: '#16a34a'
  },
  dark: {
    water: '#111827',
    waterStroke: '#374151',
    land: '#4b5563',
    landStroke: '#6b7280'
  },
  classic: {
    water: '#bfdbfe',
    waterStroke: '#3b82f6',
    land: '#fef3c7',
    landStroke: '#f59e0b'
  }
};

// Globe setup
const canvas = document.getElementById("c");
canvas.width = width;
canvas.height = height;
const ctx = canvas.getContext("2d");
const data = mapData.features;

let projection = d3
  .geoOrthographic()
  .scale(mapSettings.zoom)
  .translate([width / 2, height / 2]);

const pathGenerator = d3.geoPath(projection, ctx);

// Country coordinates (main ports)
const countryCoords = {
  'Türkiye': [28.9784, 41.0082], // Istanbul
  'Rusya': [30.3141, 59.9311], // St. Petersburg
  'Mısır': [31.2357, 30.0444], // Alexandria
  'Bulgaristan': [27.9147, 43.1956], // Varna
  'Gürcistan': [41.6168, 41.6401], // Batumi
  'Romanya': [28.6596, 44.1598], // Constanta
  'Ukrayna': [30.7326, 46.4775], // Odessa
  'Yunanistan': [23.6362, 37.9755], // Piraeus
  'Lübnan': [35.5018, 33.8938], // Beirut
  'Suriye': [35.7381, 35.1981], // Latakia
  'İtalya': [12.2946, 43.7593], // Livorno
  'Fas': [-6.8498, 33.9716], // Casablanca
  'İspanya': [-5.9844, 43.3614], // Santander
  'Fransa': [5.3698, 43.2965], // Marseille
  'Cezayir': [3.0588, 36.7753], // Algiers
  'Tunus': [10.1658, 36.8190], // Tunis
  'Libya': [13.1913, 32.8872], // Tripoli
  'Senegal': [-17.3996, 14.6928], // Dakar
  'Nijerya': [3.3792, 6.5244], // Lagos
  'Benin': [2.3158, 6.4969], // Cotonou
  'Fildişi Sahilleri': [-4.0413, 5.3364], // Abidjan
  'Gana': [-0.1969, 5.6037], // Tema
  'ABD': [-74.0059, 40.7128], // New York
  'Ürdün': [35.9106, 29.5320], // Aqaba
  'Suudi Arabistan': [39.1925, 21.4858], // Jeddah
  'Hindistan': [72.8777, 19.0760] // Mumbai
};

// Sea route waypoints for realistic maritime navigation
const seaRoutes = {
  // Mediterranean routes
  'Türkiye-İtalya': [
    [28.9784, 41.0082], // Istanbul
    [26.0, 40.0], // Aegean Sea
    [23.0, 38.0], // Greek waters
    [18.0, 39.0], // Ionian Sea
    [12.2946, 43.7593] // Livorno
  ],
  'Türkiye-Fransa': [
    [28.9784, 41.0082], // Istanbul
    [26.0, 40.0], // Aegean
    [20.0, 37.0], // Mediterranean
    [10.0, 42.0], // Corsica
    [5.3698, 43.2965] // Marseille
  ],
  'İspanya-Fas': [
    [-5.9844, 43.3614], // Santander
    [-6.0, 36.0], // Gibraltar Strait
    [-6.8498, 33.9716] // Casablanca
  ],
  // Atlantic routes
  'Fas-Senegal': [
    [-6.8498, 33.9716], // Casablanca
    [-10.0, 28.0], // Canary Islands area
    [-15.0, 20.0], // West Africa coast
    [-17.3996, 14.6928] // Dakar
  ],
  // Black Sea routes
  'Türkiye-Rusya': [
    [28.9784, 41.0082], // Istanbul
    [29.0, 42.0], // Bosphorus
    [30.0, 44.0], // Black Sea
    [30.3141, 59.9311] // St. Petersburg
  ],
  'Türkiye-Ukrayna': [
    [28.9784, 41.0082], // Istanbul
    [29.0, 42.0], // Bosphorus
    [32.0, 45.0], // Black Sea
    [30.7326, 46.4775] // Odessa
  ]
};

// ARKAS Service Routes (same as before but with enhanced data)
const arkasServices = {
  // BLACK SEA SERVICES
  'MRS': {
    name: 'MRS',
    description: 'Türkiye → Rusya → Türkiye',
    category: 'BSE',
    route: ['Türkiye', 'Rusya', 'Türkiye'],
    color: '#1e40af',
    duration: 8,
    distance: '1,250 NM'
  },
  'REX2': {
    name: 'REX2',
    description: 'Mısır → Rusya → Mısır',
    category: 'BSE',
    route: ['Mısır', 'Rusya', 'Mısır'],
    color: '#7c2d12',
    duration: 10,
    distance: '1,680 NM'
  },
  'TBS': {
    name: 'TBS',
    description: 'Türkiye → Bulgaristan → Türkiye',
    category: 'BSE',
    route: ['Türkiye', 'Bulgaristan', 'Türkiye'],
    color: '#059669',
    duration: 6,
    distance: '420 NM'
  },
  'TPS': {
    name: 'TPS',
    description: 'Türkiye → Gürcistan → Türkiye',
    category: 'BSE',
    route: ['Türkiye', 'Gürcistan', 'Türkiye'],
    color: '#7c2d12',
    duration: 6,
    distance: '380 NM'
  },
  'APS': {
    name: 'APS',
    description: 'Türkiye → Gürcistan → Türkiye',
    category: 'BSE',
    route: ['Türkiye', 'Gürcistan', 'Türkiye'],
    color: '#be185d',
    duration: 6,
    distance: '380 NM'
  },
  'TRS': {
    name: 'TRS',
    description: 'Türkiye → Romanya → Türkiye',
    category: 'BSE',
    route: ['Türkiye', 'Romanya', 'Türkiye'],
    color: '#9333ea',
    duration: 7,
    distance: '520 NM'
  },
  'UEX': {
    name: 'UEX',
    description: 'Ukrayna → Türkiye → Yunanistan → Ukrayna',
    category: 'BSE',
    route: ['Ukrayna', 'Türkiye', 'Yunanistan', 'Ukrayna'],
    color: '#0891b2',
    duration: 10,
    distance: '850 NM'
  },

  // EAST MEDITERRANEAN SERVICES
  'BMS': {
    name: 'BMS',
    description: 'Mısır → Lübnan → Suriye → Türkiye → İtalya → Fas → İspanya → Fransa → İtalya → Mısır',
    category: 'EMED',
    route: ['Mısır', 'Lübnan', 'Suriye', 'Türkiye', 'İtalya', 'Fas', 'İspanya', 'Fransa', 'İtalya', 'Mısır'],
    color: '#dc2626',
    duration: 20,
    distance: '4,200 NM'
  },
  'TLS': {
    name: 'TLS',
    description: 'Türkiye → Mısır → Lübnan → Türkiye',
    category: 'EMED',
    route: ['Türkiye', 'Mısır', 'Lübnan', 'Türkiye'],
    color: '#2563eb',
    duration: 8,
    distance: '920 NM'
  },
  'IAS': {
    name: 'IAS',
    description: 'Yunanistan → Türkiye → Yunanistan',
    category: 'EMED',
    route: ['Yunanistan', 'Türkiye', 'Yunanistan'],
    color: '#059669',
    duration: 5,
    distance: '280 NM'
  },

  // WEST MEDITERRANEAN SERVICES
  'ASA': {
    name: 'ASA',
    description: 'Fransa → İspanya → Yunanistan → Türkiye → Fransa',
    category: 'WMED',
    route: ['Fransa', 'İspanya', 'Yunanistan', 'Türkiye', 'Fransa'],
    color: '#7c2d12',
    duration: 12,
    distance: '2,150 NM'
  },
  'ITE': {
    name: 'ITE',
    description: 'İtalya → Türkiye → İtalya',
    category: 'WMED',
    route: ['İtalya', 'Türkiye', 'İtalya'],
    color: '#059669',
    duration: 6,
    distance: '680 NM'
  },
  'SPX': {
    name: 'SPX',
    description: 'İspanya → Fas',
    category: 'WMED',
    route: ['İspanya', 'Fas'],
    color: '#0891b2',
    duration: 4,
    distance: '320 NM'
  },

  // NORTH AFRICA SERVICES
  'AEX': {
    name: 'AEX',
    description: 'İtalya → Fransa → İspanya → Cezayir → İtalya',
    category: 'NAF',
    route: ['İtalya', 'Fransa', 'İspanya', 'Cezayir', 'İtalya'],
    color: '#7c2d12',
    duration: 10,
    distance: '1,580 NM'
  },
  'LTS1': {
    name: 'LTS1',
    description: 'Türkiye → Tunus → Türkiye',
    category: 'NAF',
    route: ['Türkiye', 'Tunus', 'Türkiye'],
    color: '#059669',
    duration: 6,
    distance: '750 NM'
  },
  'LTS2': {
    name: 'LTS2',
    description: 'Türkiye → Libya → Türkiye',
    category: 'NAF',
    route: ['Türkiye', 'Libya', 'Türkiye'],
    color: '#be185d',
    duration: 6,
    distance: '620 NM'
  },
  'NAS': {
    name: 'NAS',
    description: 'Türkiye → Cezayir → Türkiye',
    category: 'NAF',
    route: ['Türkiye', 'Cezayir', 'Türkiye'],
    color: '#9333ea',
    duration: 8,
    distance: '980 NM'
  },
  'OEX': {
    name: 'OEX',
    description: 'İspanya → Cezayir → İspanya',
    category: 'NAF',
    route: ['İspanya', 'Cezayir', 'İspanya'],
    color: '#0891b2',
    duration: 5,
    distance: '420 NM'
  },
  'FMS': {
    name: 'FMS',
    description: 'Fransa → Fas → Fransa',
    category: 'NAF',
    route: ['Fransa', 'Fas', 'Fransa'],
    color: '#dc2626',
    duration: 5,
    distance: '480 NM'
  },
  'WBS': {
    name: 'WBS',
    description: 'Türkiye → Fas → İspanya → Türkiye',
    category: 'NAF',
    route: ['Türkiye', 'Fas', 'İspanya', 'Türkiye'],
    color: '#2563eb',
    duration: 10,
    distance: '1,650 NM'
  },

  // WEST AFRICA SERVICES
  'WAS': {
    name: 'WAS',
    description: 'Fas → Senegal → Nijerya → Benin → Fildişi Sahilleri → Gana → Fas',
    category: 'WAF',
    route: ['Fas', 'Senegal', 'Nijerya', 'Benin', 'Fildişi Sahilleri', 'Gana', 'Fas'],
    color: '#059669',
    duration: 15,
    distance: '2,850 NM'
  },
  'MCS': {
    name: 'MCS',
    description: 'Fas → Fas (İç Hat)',
    category: 'WAF',
    route: ['Fas', 'Fas'],
    color: '#7c2d12',
    duration: 3,
    distance: '150 NM'
  },

  // NORTH AMERICA SERVICES
  'USA': {
    name: 'USA',
    description: 'Türkiye → ABD → Türkiye',
    category: 'NAM',
    route: ['Türkiye', 'ABD', 'Türkiye'],
    color: '#dc2626',
    duration: 15,
    distance: '5,200 NM'
  },

  // RED SEA & INDIA SERVICES
  'IMS': {
    name: 'IMS',
    description: 'Türkiye → Ürdün → Suudi Arabistan → Hindistan → Suudi Arabistan → Ürdün → Mısır → Türkiye',
    category: 'RSS',
    route: ['Türkiye', 'Ürdün', 'Suudi Arabistan', 'Hindistan', 'Suudi Arabistan', 'Ürdün', 'Mısır', 'Türkiye'],
    color: '#7c2d12',
    duration: 20,
    distance: '6,800 NM'
  }
};

// Current state
let currentService = null;
let currentTimeline = null;
let isPaused = false;

// Initialize application
const initApp = () => {
  setupMapSettings();
  setupTabs();
  setupServiceButtons();
  setupControls();
  drawStaticGlobe();
};

// Map settings functionality
const setupMapSettings = () => {
  // Toggle settings panel
  document.getElementById('toggleSettings').addEventListener('click', () => {
    const content = document.getElementById('settingsContent');
    content.classList.toggle('collapsed');
  });

  // Projection type change
  document.getElementById('projectionType').addEventListener('change', (e) => {
    mapSettings.projection = e.target.value;
    updateProjection();
  });

  // Color theme change
  document.getElementById('colorTheme').addEventListener('change', (e) => {
    mapSettings.colorTheme = e.target.value;
    drawStaticGlobe();
  });

  // Route type change
  document.getElementById('routeType').addEventListener('change', (e) => {
    mapSettings.routeType = e.target.value;
  });

  // Animation speed
  document.getElementById('animationSpeed').addEventListener('input', (e) => {
    mapSettings.animationSpeed = parseFloat(e.target.value);
    document.getElementById('speedValue').textContent = mapSettings.animationSpeed.toFixed(1) + 'x';
  });

  // Show labels
  document.getElementById('showLabels').addEventListener('change', (e) => {
    mapSettings.showLabels = e.target.checked;
    drawStaticGlobe();
  });

  // Zoom controls
  document.getElementById('zoomIn').addEventListener('click', () => {
    mapSettings.zoom = Math.min(mapSettings.zoom * 1.2, 1000);
    updateZoom();
  });

  document.getElementById('zoomOut').addEventListener('click', () => {
    mapSettings.zoom = Math.max(mapSettings.zoom * 0.8, 50);
    updateZoom();
  });

  // Reset view
  document.getElementById('resetView').addEventListener('click', () => {
    mapSettings.zoom = 500;
    projection.rotate([0, 0, 0]);
    updateZoom();
    drawStaticGlobe();
  });
};

// Update projection type
const updateProjection = () => {
  const projectionTypes = {
    orthographic: d3.geoOrthographic(),
    natural: d3.geoNaturalEarth1(),
    mercator: d3.geoMercator(),
    robinson: d3.geoRobinson()
  };

  projection = projectionTypes[mapSettings.projection]
    .scale(mapSettings.zoom)
    .translate([width / 2, height / 2]);

  drawStaticGlobe();
};

// Update zoom
const updateZoom = () => {
  projection.scale(mapSettings.zoom);
  document.getElementById('zoomLevel').textContent = Math.round(mapSettings.zoom);
  drawStaticGlobe();
};

// Generate sea route between two countries
const generateSeaRoute = (startCountry, endCountry) => {
  const routeKey = `${startCountry}-${endCountry}`;
  const reverseKey = `${endCountry}-${startCountry}`;
  
  if (seaRoutes[routeKey]) {
    return seaRoutes[routeKey];
  } else if (seaRoutes[reverseKey]) {
    return [...seaRoutes[reverseKey]].reverse();
  }
  
  // Fallback to direct route with intermediate points for ocean crossing
  const start = countryCoords[startCountry];
  const end = countryCoords[endCountry];
  
  if (!start || !end) return [start, end];
  
  const midLon = (start[0] + end[0]) / 2;
  const midLat = (start[1] + end[1]) / 2;
  
  // Add intermediate points for long routes
  if (Math.abs(start[0] - end[0]) > 20 || Math.abs(start[1] - end[1]) > 15) {
    return [start, [midLon, midLat], end];
  }
  
  return [start, end];
};

// Tab functionality
const setupTabs = () => {
  const tabButtons = document.querySelectorAll('.tab-button');
  const serviceCategories = document.querySelectorAll('.service-category');

  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const category = button.dataset.category;
      
      // Update active tab
      tabButtons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');
      
      // Update active service category
      serviceCategories.forEach(cat => cat.classList.remove('active'));
      document.getElementById(category).classList.add('active');
      
      // Reset current service
      resetRoute();
    });
  });
};

// Service button functionality
const setupServiceButtons = () => {
  const serviceButtons = document.querySelectorAll('.service-button');
  
  serviceButtons.forEach(button => {
    button.addEventListener('click', () => {
      const serviceId = button.dataset.service;
      const service = arkasServices[serviceId];
      
      if (service) {
        selectService(service, button);
      }
    });
  });
};

// Control buttons
const setupControls = () => {
  document.getElementById('startRoute').addEventListener('click', startRoute);
  document.getElementById('pauseRoute').addEventListener('click', pauseRoute);
  document.getElementById('resetRoute').addEventListener('click', resetRoute);
};

// Select a service
const selectService = (service, buttonElement) => {
  // Reset previous selection
  document.querySelectorAll('.service-button').forEach(btn => btn.classList.remove('active'));
  buttonElement.classList.add('active');
  
  currentService = service;
  
  // Update UI
  document.getElementById('serviceName').textContent = service.name;
  document.getElementById('routeDescription').textContent = service.description;
  document.getElementById('routeDistance').textContent = service.distance;
  document.getElementById('routeDuration').textContent = `${service.duration} saat`;
  document.getElementById('startRoute').disabled = false;
  
  // Focus on first country
  if (service.route.length > 0 && countryCoords[service.route[0]]) {
    focusOnCountry(service.route[0]);
  }
};

// Focus camera on a country
const focusOnCountry = (countryName) => {
  const coords = countryCoords[countryName];
  if (!coords) return;
  
  const rotation = [-coords[0], -coords[1], 0];
  
  gsap.to(projection, {
    duration: 2,
    ease: "power2.inOut",
    onUpdate: function() {
      const progress = this.progress();
      const currentRotation = projection.rotate();
      const newRotation = [
        currentRotation[0] + (rotation[0] - currentRotation[0]) * progress,
        currentRotation[1] + (rotation[1] - currentRotation[1]) * progress,
        0
      ];
      projection.rotate(newRotation);
      drawStaticGlobe();
    }
  });
};

// Start route animation
const startRoute = () => {
  if (!currentService) return;
  
  document.getElementById('startRoute').style.display = 'none';
  document.getElementById('pauseRoute').style.display = 'block';
  document.getElementById('resetRoute').style.display = 'block';
  
  animation.isAnimating = true;
  animateRoute();
};

// Pause route animation
const pauseRoute = () => {
  if (currentTimeline) {
    if (isPaused) {
      currentTimeline.resume();
      document.getElementById('pauseRoute').textContent = '⏸️ Duraklat';
      isPaused = false;
    } else {
      currentTimeline.pause();
      document.getElementById('pauseRoute').textContent = '▶️ Devam Et';
      isPaused = true;
    }
  }
};

// Reset route
const resetRoute = () => {
  if (currentTimeline) {
    currentTimeline.kill();
    currentTimeline = null;
  }
  
  animation.isAnimating = false;
  animation.progress = 0;
  isPaused = false;
  
  document.getElementById('startRoute').style.display = 'block';
  document.getElementById('pauseRoute').style.display = 'none';
  document.getElementById('resetRoute').style.display = 'none';
  document.getElementById('pauseRoute').textContent = '⏸️ Duraklat';
  document.getElementById('progressBar').style.width = '0%';
  
  // Clear service selection
  document.querySelectorAll('.service-button').forEach(btn => btn.classList.remove('active'));
  document.getElementById('serviceName').textContent = 'Servis Seçin';
  document.getElementById('routeDescription').textContent = 'Haritada görmek istediğiniz servisi seçin';
  document.getElementById('routeDistance').textContent = '-';
  document.getElementById('routeDuration').textContent = '-';
  document.getElementById('startRoute').disabled = true;
  currentService = null;
  
  drawStaticGlobe();
};

// Animate route
const animateRoute = () => {
  if (!currentService) return;
  
  const route = currentService.route;
  const duration = currentService.duration / mapSettings.animationSpeed;
  
  currentTimeline = gsap.timeline({
    onComplete: () => {
      animation.isAnimating = false;
      document.getElementById('pauseRoute').style.display = 'none';
      document.getElementById('startRoute').style.display = 'block';
    }
  });
  
  // Animate through each segment of the route
  for (let i = 0; i < route.length - 1; i++) {
    const startCountry = route[i];
    const endCountry = route[i + 1];
    const segmentDuration = duration / (route.length - 1);
    
    currentTimeline.to(animation, {
      duration: segmentDuration,
      progress: (i + 1) / (route.length - 1),
      ease: "power2.inOut",
      onUpdate: () => {
        const progress = animation.progress;
        document.getElementById('progressBar').style.width = `${progress * 100}%`;
        drawRouteProgress(route, progress);
      }
    });
  }
};

// Draw static globe
const drawStaticGlobe = () => {
  ctx.clearRect(0, 0, width, height);
  
  const theme = colorThemes[mapSettings.colorTheme];
  
  // Draw ocean
  ctx.beginPath();
  pathGenerator({ type: "Sphere" });
  ctx.fillStyle = theme.water;
  ctx.fill();
  ctx.strokeStyle = theme.waterStroke;
  ctx.lineWidth = 2;
  ctx.stroke();
  
  // Draw countries
  data.forEach(feature => {
    ctx.beginPath();
    pathGenerator(feature);
    ctx.fillStyle = theme.land;
    ctx.fill();
    ctx.strokeStyle = theme.landStroke;
    ctx.lineWidth = 0.5;
    ctx.stroke();
  });
  
  // Draw port labels if enabled
  if (mapSettings.showLabels && currentService) {
    currentService.route.forEach(country => {
      drawPortLabel(country);
    });
  }
};

// Draw port label
const drawPortLabel = (countryName) => {
  const coords = countryCoords[countryName];
  if (!coords) return;
  
  const [x, y] = projection(coords);
  
  // Check if point is visible
  if (x < 0 || x > width || y < 0 || y > height) return;
  
  ctx.save();
  ctx.fillStyle = '#1f2937';
  ctx.font = '12px Inter, sans-serif';
  ctx.fontWeight = '600';
  ctx.textAlign = 'center';
  
  // Background
  const textWidth = ctx.measureText(countryName).width;
  ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
  ctx.fillRect(x - textWidth/2 - 4, y - 18, textWidth + 8, 16);
  
  // Text
  ctx.fillStyle = '#1f2937';
  ctx.fillText(countryName, x, y - 6);
  ctx.restore();
};

// Draw route progress
const drawRouteProgress = (route, progress) => {
  drawStaticGlobe();
  
  if (!currentService) return;
  
  const totalSegments = route.length - 1;
  const currentSegment = Math.floor(progress * totalSegments);
  const segmentProgress = (progress * totalSegments) % 1;
  
  // Draw completed segments
  for (let i = 0; i < currentSegment; i++) {
    drawSegment(route[i], route[i + 1], 1, currentService.color);
  }
  
  // Draw current segment
  if (currentSegment < totalSegments) {
    drawSegment(route[currentSegment], route[currentSegment + 1], segmentProgress, currentService.color);
  }
  
  // Draw ports
  route.forEach((country, index) => {
    if (countryCoords[country]) {
      const isActive = index <= currentSegment || (index === currentSegment + 1 && segmentProgress > 0);
      drawPort(country, isActive);
    }
  });
};

// Draw segment between two countries
const drawSegment = (startCountry, endCountry, progress, color) => {
  const routePoints = mapSettings.routeType === 'sea' 
    ? generateSeaRoute(startCountry, endCountry)
    : [countryCoords[startCountry], countryCoords[endCountry]];
  
  if (!routePoints || routePoints.length < 2) return;
  
  const totalPoints = Math.floor(progress * (routePoints.length - 1) * 20);
  const points = [];
  
  for (let i = 0; i < routePoints.length - 1; i++) {
    const segmentPoints = Math.floor(totalPoints / (routePoints.length - 1));
    const interpolator = d3.geoInterpolate(routePoints[i], routePoints[i + 1]);
    
    for (let j = 0; j <= segmentPoints && points.length < totalPoints; j++) {
      points.push(interpolator(j / 20));
    }
  }
  
  if (points.length > 1) {
    ctx.beginPath();
    pathGenerator({ type: "LineString", coordinates: points });
    ctx.strokeStyle = color;
    ctx.lineWidth = 4;
    ctx.lineCap = "round";
    ctx.stroke();
    
    // Draw ship at current position
    if (progress > 0 && progress < 1 && points.length > 0) {
      const shipPos = points[points.length - 1];
      drawShip(shipPos);
    }
  }
};

// Draw port
const drawPort = (countryName, isActive) => {
  const coords = countryCoords[countryName];
  if (!coords) return;
  
  const [x, y] = projection(coords);
  
  ctx.beginPath();
  ctx.arc(x, y, isActive ? 8 : 5, 0, Math.PI * 2);
  ctx.fillStyle = isActive ? "#ef4444" : "#6b7280";
  ctx.fill();
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 2;
  ctx.stroke();
};

// Draw ship
const drawShip = (coords) => {
  const [x, y] = projection(coords);
  
  ctx.save();
  ctx.translate(x, y);
  
  // Ship body
  ctx.beginPath();
  ctx.arc(0, 0, 8, 0, Math.PI * 2);
  ctx.fillStyle = "#fbbf24";
  ctx.fill();
  ctx.strokeStyle = "#f59e0b";
  ctx.lineWidth = 2;
  ctx.stroke();
  
  // Ship icon
  ctx.fillStyle = "#ffffff";
  ctx.font = "14px Arial";
  ctx.textAlign = "center";
  ctx.fillText("🚢", 0, 5);
  
  ctx.restore();
};

// Animation loop
const animate = () => {
  if (!animation.isAnimating) {
    drawStaticGlobe();
  }
  requestAnimationFrame(animate);
};

// Resize handler
window.addEventListener('resize', () => {
  const newWidth = window.innerWidth;
  const newHeight = window.innerHeight;
  
  if (newWidth !== width || newHeight !== height) {
    width = newWidth;
    height = newHeight;
    canvas.width = width;
    canvas.height = height;
    
    projection.translate([width / 2, height / 2]);
    drawStaticGlobe();
  }
});

// Initialize app
initApp();
animate();